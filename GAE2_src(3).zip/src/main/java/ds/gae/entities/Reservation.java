package ds.gae.entities;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class Reservation extends Quote {

	private static final long serialVersionUID = -3134716360420261068L;
	private int carId;

	public Reservation() {
    }
    
    /***************
	 * CONSTRUCTOR *
	 ***************/

    public Reservation(Quote quote, int carId) {
    	super(quote.getCarRenter(), quote.getStartDate(), quote.getEndDate(), 
    			quote.getRentalCompany(), quote.getCarType(), quote.getRentalPrice());
        this.carId = carId;
    }
    
    /******
     * ID *
     ******/
    
    public int getCarId() {
    	return carId;
    }
    
    /*************
     * TO STRING *
     *************/
    
    @Override
    public String toString() {
        return String.format("Reservation for %s from %s to %s at %s\nCar type: %s\tCar: %s\nTotal price: %.2f", 
                getCarRenter(), getStartDate(), getEndDate(), getRentalCompany(), getCarType(), getCarId(), getRentalPrice());
    }
    
    @Override
    public boolean equals(Object o) {
    	if (o instanceof Reservation &&
    			((Reservation) o).carId == carId &&
    			super.equals(o))
    		return true;

    	return false;
    }
    
    @Override
    public int hashCode(){
    	return carId*13;
    }
    
}