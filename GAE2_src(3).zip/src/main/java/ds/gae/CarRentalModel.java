package ds.gae;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;


import ds.gae.entities.*;
 
public class CarRentalModel {
	public Map<String,CarRentalCompany> CRCS = new HashMap<String,CarRentalCompany>();	
	private static CarRentalModel instance;
	public static CarRentalModel get() {
		if (instance == null)
			instance = new CarRentalModel();
		return instance;
	}
		
	public Set<String> getCarTypesNames(String crcName) {
    	EntityManager em = EMF.get().createEntityManager();
    	
    	CarRentalCompany crc = em.find(CarRentalCompany.class, crcName);
    
    	Set<String> out = new HashSet<String>();
    	for (CarType carType : crc.getAllTypes()) {
    		out.add(carType.getName());
    	}
    	em.close();
    	 
		return out;
	}

    public Collection<String> getAllRentalCompanyNames() {
    	EntityManager em = EMF.get().createEntityManager();
    	
    	@SuppressWarnings("rawtypes")
		List l = em.createQuery("SELECT c.name FROM CarRentalCompany c").getResultList();
        HashSet<String> out = new HashSet<String>();
    	
        if (l != null) {
            for (Object name : l) {
                out.add((String) name);
            }
        }
        
    	em.close();
        return out;
    }

    public Quote createQuote(String company, String clientName, ReservationConstraints constraints) throws ReservationException {
    	EntityManager em = EMF.get().createEntityManager();
    	CarRentalCompany crc = em.find(CarRentalCompany.class, company);
    	Quote out = null;

    	try {
	        if (crc != null) {
	            out = crc.createQuote(constraints, clientName);
	        } else {
	        	throw new ReservationException("CarRentalCompany not found.");    	
	        }
    	} 
    	finally {
            em.close();        
    	}
        
        return out;
    }

	public List<Reservation> getReservations(String renter) {
    	EntityManager em = EMF.get().createEntityManager();
    	
    	List<Reservation> out = (List<Reservation>) em.createQuery("SELECT r FROM Reservation r WHERE r.carRenter = ?1").setParameter(1, renter).getResultList();
    	return out;
    }
    
    public List<Reservation> confirmQuotes(List<Quote> quotes) throws ReservationException {    	
    	
        List<Reservation> done = new LinkedList<Reservation>();
        try {
            for (Quote quote : quotes) {
            	EntityManager em = EMF.get().createEntityManager();
                CarRentalCompany crc = em.find(CarRentalCompany.class, quote.getRentalCompany());
                if (crc == null)
                    throw new ReservationException(String.format("CarRentalCompany %s not found.", quote.getRentalCompany()));
                Reservation r = crc.confirmQuote(quote);
                done.add(r);
                em.close();
            }
        } catch (ReservationException e) {
        	for (Reservation r : done) {
            	EntityManager em = EMF.get().createEntityManager();
        		String carRentalCompanyName = r.getRentalCompany();
        		CarRentalCompany crc = em.find(CarRentalCompany.class, carRentalCompanyName);
        		crc.cancelReservation(r);        		
                em.close();
        	} 
            throw e;
        } finally {
            //em.close();
        }
        return done;
    }

    /********************************************
     * Methods only needed for Persistence Test *
     ********************************************/
    
	public void confirmQuote(Quote q) throws ReservationException {
    	EntityManager em = EMF.get().createEntityManager();
        try {
                CarRentalCompany crc = em.find(CarRentalCompany.class, q.getRentalCompany());
                if (crc == null)
                    throw new ReservationException(String.format("CarRentalCompany %s not found.", q.getRentalCompany()));
                crc.confirmQuote(q);
        } finally {
            em.close();
        }
	}

    public Collection<CarType> getCarTypesOfCarRentalCompany(String crcName) {
    	EntityManager em = EMF.get().createEntityManager();
    	CarRentalCompany crc = em.find(CarRentalCompany.class, crcName);
    	Collection<CarType> out = new ArrayList<CarType>(crc.getAllTypes());
    	em.close();
        return out;
    }
	
    
    public Collection<Integer> getCarIdsByCarType(String crcName, CarType carType) {
    	Collection<Integer> out = new ArrayList<Integer>();
    	for (Car c : getCarsByCarType(crcName, carType)) {
    		out.add(c.getId());
    	}
    	return out;
    }

    public int getAmountOfCarsByCarType(String crcName, CarType carType) {
    	return this.getCarsByCarType(crcName, carType).size();
    }

	private List<Car> getCarsByCarType(String crcName, CarType carType) {				
    	EntityManager em = EMF.get().createEntityManager();
		CarType carTypeAttached = em.find(CarType.class, carType.getId());
    	List<Car> out = new ArrayList<Car>(carTypeAttached.getCars());
    	em.close();
    	return out;
	}

	public boolean hasReservations(String renter) {
		return this.getReservations(renter).size() > 0;		
	}
	
}
